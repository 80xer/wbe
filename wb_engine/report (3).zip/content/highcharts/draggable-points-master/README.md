draggable-points
================
This plugin allows the user to drag the points in the chart, making them able to edit data directly in the chart.

The contents of the plugin is located in the javascript file "draggable-points.js". 
This plugin is published under the MIT license, and the license document is included in the repository.

Online demo: http://jsfiddle.net/highcharts/AyUbx/
